<?php

include "conexao.php";


$usu = $_POST["usuario_email"];
$sen = $_POST["senha"];

$teste = mysqli_query($conexao,"insert into usuario(usuario_email,senha) values ('$usu','$sen')");


    
if ($teste){
    echo "<script>
    location.href='logarusuario.html'
    </script>";
}else{
    echo "<script>alert ('Este usuario já existe.')
    location.href='cadusuario.html'
    </script>";
}
 
?>