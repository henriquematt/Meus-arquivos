<?php
    
    include "conexao.php";

    $login = $_POST["entrar"];
    $senha = $_POST["senha"];

    $sql = mysqli_query($conexao,"select * from usuario where
    usuario_email= '$login' and senha= '$senha'");

    $linha = mysqli_fetch_array($sql);
    
    if($linha == 0){
        echo "<script> alert ('Senha ou Login incorreto.')
        location.href='logarusuario.html' </script>";
    }else{
        echo "<script> 
        location.href='../index.html' </script>";
    }
 
?>